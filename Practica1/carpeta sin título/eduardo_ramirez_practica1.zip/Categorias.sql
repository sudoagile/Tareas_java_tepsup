CREATE TABLE Categorias (
Categoria_ID INT PRIMARY KEY,
Nombre VARCHAR(255)
);
